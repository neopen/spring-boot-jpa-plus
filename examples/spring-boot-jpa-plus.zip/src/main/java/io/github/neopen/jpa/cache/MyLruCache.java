package io.github.neopen.jpa.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

// 丢弃最近最少使用的（最久创建的且未用过）
public class MyLruCache<V> {

    /**
     * 容量
     */
    private int capacity = 1024;

    /**
     * Node记录表
     */
    private final Map<String, ListNode<String, V>> table = new ConcurrentHashMap<>();
    /**
     * 双向链表头部
     */
    private final ListNode<String, V> head;
    /**
     * 双向链表尾部
     */
    private ListNode<String, V> tail;

    public MyLruCache(int capacity) {
        this();
        this.capacity = capacity;
    }

    public MyLruCache() {
        head = new ListNode<>(null, null);
        tail = new ListNode<>(null, null);
        head.next = tail;
        head.prev = null;
        tail.prev = head;
        tail.next = null;
    }

    public V get(String key) {
        ListNode<String, V> node = table.get(key);
        //如果Node不在表中，代表缓存中并没有
        if (node == null) {
            return null;
        }
        //如果存在，则需要移动Node节点到表头

        //截断链表，node.prev -> node  -> node.next ====> node.prev -> node.next
        //         node.prev <- node <- node.next  ====>  node.prev <- node.next
        node.prev.next = node.next;
        node.next.prev = node.prev;

        //移动节点到表头
        node.next = head.next;
        head.next.prev = node;
        node.prev = head;
        head.next = node;
        //存在缓存表
        table.put(key, node);
        return node.value;
    }

    public void put(String key, V value) {
        ListNode<String, V> node = table.get(key);
        //如果Node不在表中，代表缓存中并没有
        if (node == null) {
            if (table.size() == capacity) {
                //超过容量了 ,首先移除尾部的节点
                table.remove(tail.prev.key);
                tail.prev = tail.next;
                tail.next = null;
                tail = tail.prev;
            }
            node = new ListNode<>(key, value);
            table.put(key, node);
        }
        //如果存在，则需要移动Node节点到表头
        node.next = head.next;
        head.next.prev = node;
        node.prev = head;
        head.next = node;
    }

    /**
     * 双向链表内部类
     */
    public static class ListNode<K, V> {
        private final K key;
        private final V value;
        private ListNode<K, V> prev;
        private ListNode<K, V> next;

        public ListNode(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return "ListNode{" + "key=" + key + ", value=" + value + '}';
        }
    }


    public static void main(String[] args) {
        MyLruCache<ListNode> cache = new MyLruCache<>(4);
        ListNode<String, Integer> node1 = new ListNode<>("key1", 1);
        ListNode<String, Integer> node2 = new ListNode<>("key2", 2);
        ListNode<String, Integer> node3 = new ListNode<>("key3", 3);
        ListNode<String, Integer> node4 = new ListNode<>("key4", 4);
        ListNode<String, Integer> node5 = new ListNode<>("key5", 5);
        cache.put("key1", node1);
        cache.put("key2", node2);
        cache.put("key3", node3);
        cache.put("key4", node4);
        System.out.println(cache.get("key1"));

        cache.put("key5", node5);
        System.out.println(cache.get("key2"));
        System.out.println(cache.get("key3"));

    }
}
